import os

FLAG = "labyrinth{fake_flag}"
KEY = os.urandom(2)
inner_flag = FLAG.split('labyrinth{')[1][:-1]
ct = [ord(char) ^ KEY[i % 2] for i, char in enumerate(inner_flag)]

print("ct =", ct)
